package com.dini.miagendaapp.adaptadores;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.dini.miagendaapp.R;
import com.dini.miagendaapp.actividades.MainActivity;
import com.dini.miagendaapp.modelos.Item;
import com.dini.miagendaapp.utilidades.Utils;

import java.util.ArrayList;
import java.util.Collections;

public class CustomItemsAdapter extends ArrayAdapter<Item> implements Filterable
{
    public ArrayList<Item> items;
    public ArrayList<Item> filteredItems;
    private Filter filter;
    private Context context;

    public CustomItemsAdapter(Context context, ArrayList<Item> items)
    {
        super(context, 0, items);

        this.items = new ArrayList<>();
        this.items.addAll(items);

        this.filteredItems = new ArrayList<>();
        this.filteredItems.addAll(items);

        this.context = context;
    }

    @Override
    public void add(Item item)
    {
        this.filteredItems.add(item);
        Collections.sort(this.filteredItems);

        this.items.add(item);
        Collections.sort(this.items);

        notifyDataSetChanged();
    }

    @Override
    public void remove(Item item)
    {
        this.filteredItems.remove(item);
        Collections.sort(this.filteredItems);

        this.items.remove(item);
        Collections.sort(this.items);

        notifyDataSetChanged();
    }

    @Override
    public int getCount()
    {
        return filteredItems.size();
    }

    @Override
    public Item getItem(int position)
    {
        return filteredItems.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent)
    {
        LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.item, null);

        Item item = filteredItems.get(position);

        if (item != null)
        {
            TextView tvName = (TextView) view.findViewById(R.id.tvItem);
            TextView tvInCharge = (TextView) view.findViewById(R.id.tvInCharge);
            TextView tvAppointmentWith = (TextView) view.findViewById(R.id.tvAppointmentWith);
            TextView tvPriority = (TextView) view.findViewById(R.id.tvItemPriority);

            CheckBox checkBox = (CheckBox) view.findViewById(R.id.cbItemCheck);
            checkBox.setOnCheckedChangeListener((MainActivity) context);

            tvInCharge.setVisibility(item.inCharge == null || item.inCharge.isEmpty() ? View.GONE : View.VISIBLE);
            tvAppointmentWith.setVisibility(item.appointmentWith == null || item.appointmentWith.isEmpty() ? View.GONE : View.VISIBLE);

            tvName.setText(item.subject);
            if (item.inCharge != null && !item.inCharge.isEmpty()) tvInCharge.setText("Encargado: " + item.inCharge);
            if (item.appointmentWith != null && !item.appointmentWith.isEmpty()) tvAppointmentWith.setText("Cita con: " + item.appointmentWith);
            tvPriority.setText(item.priority.getName());
            tvPriority.setTextColor(item.priority.getColor());
            TextView dueDate = (TextView) view.findViewById(R.id.tvDueDate);

            dueDate.setVisibility(!TextUtils.isEmpty(Utils.getStringFromDate(item.dueDate)) ? View.VISIBLE : View.GONE);
            dueDate.setText(!TextUtils.isEmpty(Utils.getStringFromDate(item.dueDate)) && !TextUtils.isEmpty(item.dueTime)
                    ? Utils.getStringFromDateAndTime(item.dueDate) : Utils.getStringFromDate(item.dueDate));
        }

        return view;
    }

    @Override
    public Filter getFilter()
    {
        if (filter == null) filter = new ItemsFilter();

        return filter;
    }

    private class ItemsFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            FilterResults filterResults = new FilterResults();
            String prefix = constraint.toString().toLowerCase();

            if (prefix.length() == 0)
            {
                ArrayList<Item> list = new ArrayList<>(items);
                filterResults.values = list;
                filterResults.count = list.size();
            }
            else
            {
                final ArrayList<Item> list = new ArrayList<>(items);
                final ArrayList<Item> nlist = new ArrayList<>();
                int count = list.size();

                for (int i=0; i<count; i++)
                {
                    final Item item = list.get(i);
                    final String value = item.subject.toLowerCase();

                    if (value.contains(prefix)) nlist.add(item);
                }

                filterResults.values = nlist;
                filterResults.count = nlist.size();
            }

            return filterResults;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredItems = (ArrayList<Item>)results.values;
            CustomItemsAdapter.this.notifyDataSetChanged();
        }
    }
}
