package com.dini.miagendaapp.actividades;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.dini.miagendaapp.R;
import com.dini.miagendaapp.adaptadores.CustomItemsAdapter;
import com.dini.miagendaapp.modelos.Item;
import com.dini.miagendaapp.modelos.Priority;
import com.dini.miagendaapp.utilidades.DBUtils;
import com.dini.miagendaapp.utilidades.Utils;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements OnClickListener, SearchView.OnQueryTextListener, CompoundButton.OnCheckedChangeListener
{
    ArrayList<Item> items = new ArrayList<>();
    CustomItemsAdapter customItemsAdapter;
    ListView listView;
    EditText editText;
    ImageView imgTick, spkBtn;
    FloatingActionButton fab;
    MenuItem deleteItems, searchItem;

    private static Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        mContext = this;

        setContentView(R.layout.activity_main);

        populateItems();

        listView = (ListView) findViewById(R.id.lvDisplay);
        listView.setAdapter(customItemsAdapter);
        findViewById(R.id.spkBtn).setOnClickListener(this);
        imgTick = (ImageView)findViewById(R.id.imgTick);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        spkBtn = (ImageView) findViewById(R.id.spkBtn);
        editText = (EditText) findViewById(R.id.etAddText);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
        {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {
                final int pos = position;
                new MaterialDialog.Builder(MainActivity.this)
                        .title("Confirmar")
                        .content("¿Está seguro?")
                        .positiveText("Si")
                        .onPositive(new MaterialDialog.SingleButtonCallback()
                        {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which)
                            {
                                Item itemToBeDeleted = customItemsAdapter.getItem(pos);
                                Item.delete(Item.class, itemToBeDeleted.getId());
                                customItemsAdapter.remove(itemToBeDeleted);
                                items.remove(itemToBeDeleted);
                                Toast.makeText(MainActivity.this, "Eliminado", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .negativeText("No")
                        .show();

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(MainActivity.this, NewItem.class);
                intent.putExtra("subject", customItemsAdapter.getItem(position).subject);
                intent.putExtra("inCharge", customItemsAdapter.getItem(position).inCharge);
                intent.putExtra("appointmentWith", customItemsAdapter.getItem(position).appointmentWith);
                intent.putExtra("priority", customItemsAdapter.getItem(position).priority);
                intent.putExtra("date", customItemsAdapter.getItem(position).dueDate);
                intent.putExtra("time", customItemsAdapter.getItem(position).dueTime);
                intent.putExtra("position", position);
                startActivityForResult(intent, 202);
            }
        });

        editText.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3)
            {
                listView.smoothScrollToPosition(listView.getCount() -1);

                fab.setVisibility(!TextUtils.isEmpty(cs.toString().trim()) ? View.INVISIBLE : View.VISIBLE);
                imgTick.setVisibility(!TextUtils.isEmpty(cs.toString().trim()) ? View.VISIBLE : View.INVISIBLE);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) { }

            @Override
            public void afterTextChanged(Editable arg0) { }
        });
    }

    private void populateItems()
    {
        items = (ArrayList<Item>) DBUtils.readAll();
        Collections.sort(items);
        customItemsAdapter = new CustomItemsAdapter(this, items);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        Drawable drawableSearch = menu.findItem(R.id.search).getIcon();

        if (drawableSearch != null)
        {
            drawableSearch.mutate();
            drawableSearch.setTint(Color.WHITE);
        }

        Drawable drawableDelete = menu.findItem(R.id.deleteItems).getIcon();

        if (drawableDelete != null)
        {
            drawableDelete.mutate();
            drawableDelete.setTint(Color.WHITE);
        }

        searchItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.findViewById(android.support.v7.appcompat.R.id.search_plate).setBackgroundColor(Color.WHITE);

        EditText searchEditText = (EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(Color.BLACK);
        searchView.setOnQueryTextListener(this);

        deleteItems = menu.findItem(R.id.deleteItems);
        deleteItems.setVisible(false);

        MenuItemCompat.setOnActionExpandListener(searchItem, new MenuItemCompat.OnActionExpandListener()
        {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item)
            {
                fab.setVisibility(View.INVISIBLE);
                spkBtn.setVisibility(View.INVISIBLE);
                editText.setVisibility(View.INVISIBLE);

                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item)
            {
                fab.setVisibility(View.VISIBLE);
                spkBtn.setVisibility(View.VISIBLE);
                editText.setVisibility(View.VISIBLE);

                return true;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        switch (id)
        {
            default: return super.onOptionsItemSelected(item);
        }
    }

    public void onShareClick(MenuItem view)
    {
        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        intent.setType("text/plain");

        StringBuilder shareBodyBuilder = new StringBuilder();

        for(int i = 0; i < items.size(); i++)
        {
            shareBodyBuilder.append(i).append(1).append(". ").append(items.get(i).subject);

            if(!TextUtils.isEmpty(Utils.getStringFromDate(items.get(i).dueDate)))
               shareBodyBuilder.append(" en ").append(Utils.getStringFromDate(items.get(i).dueDate));

            shareBodyBuilder.append("\n");
        }

        intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Tareas");
        intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyBuilder.toString());
        startActivity(Intent.createChooser(intent, "Compartir por"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == 201  && resultCode == RESULT_OK)
        {
            ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            editText.append(thingsYouSaid.get(0));
            editText.requestFocus();
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }

        if (requestCode==202  && resultCode==200)
        {
            int position = data.getExtras().getInt("position");

            Item newItem = position >= 0 ? customItemsAdapter.getItem(position) : new Item();

            newItem.subject = data.getExtras().getString("subject");
            newItem.inCharge = data.getExtras().getString("inCharge");
            newItem.appointmentWith = data.getExtras().getString("appointmentWith");
            String strDate = data.getExtras().getString("date");
            String strTime = data.getExtras().getString("time");

            if(!TextUtils.isEmpty(strDate) && TextUtils.isEmpty(strTime)) newItem.dueDate = Utils.getDateFromString(strDate);
            else if(!TextUtils.isEmpty(strDate)) newItem.dueDate = Utils.getDateAndTimeFromString(strDate + " " + strTime);

            if(TextUtils.isEmpty(strDate)) newItem.dueDate = null;
            if(TextUtils.isEmpty(strTime)) newItem.dueTime = null;

            newItem.dueTime = strTime;
            newItem.priority = (Priority) data.getSerializableExtra("Priority");

            if(position == -1)
            {
                customItemsAdapter.add(newItem);
                items.add(newItem);
            }

            Collections.sort(customItemsAdapter.items);
            Collections.sort(customItemsAdapter.filteredItems);

            customItemsAdapter.notifyDataSetChanged();

            DBUtils.writeOne(newItem);
        }
    }

    public void onAddFull(View view)
    {
        Intent intent = new Intent(MainActivity.this, NewItem.class);
        startActivityForResult(intent, 202);
    }

    public void onClick(View view)
    {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

        try
        {
            startActivityForResult(intent, 201);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this, "Error al inicializar el motor de voz a texto.", Toast.LENGTH_LONG).show();
        }
    }

    public void onTickClick(View view)
    {
        String newItem = editText.getText().toString().trim();

        if(!TextUtils.isEmpty(newItem))
        {
            Item item = new Item(newItem);
            item.priority = Priority.LOW;
            customItemsAdapter.add(item);
            editText.setText("");
            listView.smoothScrollToPosition(listView.getCount() -1);
            Collections.sort(items);
            DBUtils.writeOne(item);
            items.add(item);
            Collections.sort(items);
        }
    }

    @Override
    public boolean onQueryTextSubmit(String query)
    {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText)
    {
        MainActivity.this.customItemsAdapter.getFilter().filter(newText);
        return true;
    }

    ArrayList<Item> deleteList = new ArrayList<>();

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {
        int pos = listView.getPositionForView(buttonView);
        Item tempItem = customItemsAdapter.getItem(pos);

        if(isChecked)
        {
            if(!deleteList.contains(tempItem)) deleteList.add(tempItem);
        }
        else
        {
            if(deleteList.contains(tempItem)) deleteList.remove(tempItem);
        }

        if(isChecked || deleteList.size() > 0)
        {
            searchItem.setVisible(false);
            deleteItems.setVisible(true);
        }

        if(deleteList.size() == 0)
        {
            searchItem.setVisible(true);
            deleteItems.setVisible(false);
        }
    }

    public void deleteItems(MenuItem item)
    {
        for(Item temp: deleteList)
        {
            Item.delete(Item.class, temp.getId());
            customItemsAdapter.remove(temp);
            items.remove(temp);
            Collections.sort(items);
        }

        deleteList.clear();
        deleteItems.setVisible(false);
        searchItem.setVisible(true);
    }

    public static Context getContext()
    {
        return mContext;
    }
}