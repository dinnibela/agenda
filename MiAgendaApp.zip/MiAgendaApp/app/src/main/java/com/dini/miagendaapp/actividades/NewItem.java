package com.dini.miagendaapp.actividades;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.dini.miagendaapp.R;
import com.dini.miagendaapp.modelos.Priority;
import com.dini.miagendaapp.utilidades.Utils;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.RadialPickerLayout;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class NewItem extends AppCompatActivity implements View.OnClickListener, TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener
{
    private EditText etNewTask;
    private EditText etInCharge;
    private EditText etAppointmentWith;
    private EditText timeTextView;
    private EditText dateTextView;
    private Spinner spinner;

    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Priority.values()));

        // Find our View instances
        etNewTask = (EditText)findViewById(R.id.etNewTask);
        etInCharge = (EditText)findViewById(R.id.etInCharge);
        etAppointmentWith = (EditText)findViewById(R.id.etAppointmentWith);
        timeTextView = (EditText)findViewById(R.id.etDisplayTime);
        dateTextView = (EditText)findViewById(R.id.etDisplayDate);
        ImageView timeButton = (ImageView)findViewById(R.id.imgTime);
        ImageView dateButton = (ImageView)findViewById(R.id.imgDate);

        String subject = getIntent().getStringExtra("subject");
        String inCharge = getIntent().getStringExtra("inCharge");
        String appointmentWith = getIntent().getStringExtra("appointmentWith");
        position = getIntent().getIntExtra("position", -1);
        Priority priority = (Priority) getIntent().getSerializableExtra("priority");
        Date date = (Date) getIntent().getSerializableExtra("date");
        String time = getIntent().getStringExtra("time");

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        if(!TextUtils.isEmpty(subject)) etNewTask.append(subject);
        if(!TextUtils.isEmpty(inCharge)) etInCharge.append(inCharge);
        if(!TextUtils.isEmpty(appointmentWith)) etAppointmentWith.append(appointmentWith);
        if(priority == Priority.HIGH) spinner.setSelection(2);
        else if(priority == Priority.MEDIUM) spinner.setSelection(1);
        else spinner.setSelection(0);
        if(!TextUtils.isEmpty(Utils.getStringFromDate(date))) dateTextView.setText(Utils.getStringFromDate(date));
        if(!TextUtils.isEmpty(time)) timeTextView.setText(time);

        timeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Calendar calendar = Calendar.getInstance();
                TimePickerDialog tpd = TimePickerDialog.newInstance(
                        NewItem.this,
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),
                        false
                );
                tpd.show(getFragmentManager(), "Timepickerdialog");
            }
        });

        dateButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Calendar calendar = Calendar.getInstance();
                DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                        NewItem.this,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                );
                datePickerDialog.show(getFragmentManager(), "Datepickerdialog");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_new, menu);

        Drawable drawable = menu.findItem(R.id.newadd).getIcon();

        if (drawable != null)
        {
            drawable.mutate();
            drawable.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        }

        Drawable drawable1 = menu.findItem(R.id.shareNew).getIcon();

        if (drawable1 != null)
        {
            drawable1.mutate();
            drawable1.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        }

        return true;
    }

    @Override
    public void onClick(View view) { }

    @Override
    public void onResume()
    {
        super.onResume();

        TimePickerDialog timePickerDialog = (TimePickerDialog) getFragmentManager().findFragmentByTag("Timepickerdialog");
        DatePickerDialog datePickerDialog = (DatePickerDialog) getFragmentManager().findFragmentByTag("Datepickerdialog");

        if(timePickerDialog != null) timePickerDialog.setOnTimeSetListener(this);
        if(datePickerDialog != null) datePickerDialog.setOnDateSetListener(this);
    }

    @Override
    public void onTimeSet(RadialPickerLayout view, int hourOfDay, int minute, int second)
    {
        String hourString = hourOfDay < 10 ? "0"+hourOfDay : ""+hourOfDay;
        String minuteString = minute < 10 ? "0"+minute : ""+minute;
        String time = hourString+":"+minuteString;
        timeTextView.setText(time);
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth)
    {
        String date = (++monthOfYear)+"/"+dayOfMonth+"/"+year;
        dateTextView.setText(date);
    }

    public void clearDate(View view)
    {
        dateTextView.setText("");
    }

    public void clearTime(View view)
    {
        timeTextView.setText("");
    }

    public void onAddNewSaveClick(MenuItem item)
    {
        if(TextUtils.isEmpty(etNewTask.getText().toString().trim()))
            Toast.makeText(NewItem.this, "La tarea no puede estar en blanco", Toast.LENGTH_SHORT).show();
        else
        {
            InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(etNewTask.getWindowToken(), 0);

            Intent intent = new Intent();
            intent.putExtra("subject", etNewTask.getText().toString());
            intent.putExtra("inCharge", etInCharge.getText().toString());
            intent.putExtra("appointmentWith", etAppointmentWith.getText().toString());
            System.out.println("NewActivity position " + position);
            intent.putExtra("position", position);
            intent.putExtra("date", dateTextView.getText().toString());
            intent.putExtra("time", timeTextView.getText().toString());
            Priority priority = (Priority) spinner.getSelectedItem();
            intent.putExtra("Priority", priority);
            setResult(200, intent);
            this.finish();
        }
    }

    public void onDateSet(View view)
    {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                NewItem.this,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show(getFragmentManager(), "Datepickerdialog");
    }

    public void onTimeSet(View view)
    {
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog timePickerDialog = TimePickerDialog.newInstance(
                NewItem.this,
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        );
        timePickerDialog.show(getFragmentManager(), "Timepickerdialog");
    }

    public void onSpkBtnClick(View view)
    {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

        try
        {
            startActivityForResult(intent, 201);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this, "Error al inicializar el motor de voz a texto.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == 201 && resultCode == RESULT_OK)
        {
            ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            etNewTask.append(!TextUtils.isEmpty(etNewTask.getText().toString().trim()) ? " " + thingsYouSaid.get(0) : thingsYouSaid.get(0));
            etNewTask.requestFocus();

            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
    }

    public void onShareClick(MenuItem view)
    {
        if(!TextUtils.isEmpty(etNewTask.getText().toString()))
        {
            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
            intent.setType("text/plain");

            String shareBody = "";
            shareBody += etNewTask.getText().toString();

            if(!TextUtils.isEmpty(dateTextView.getText().toString()))
            {
                shareBody += " en " + dateTextView.getText().toString();

                if(!TextUtils.isEmpty(timeTextView.getText().toString())) shareBody += " " + timeTextView.getText().toString();
            }

            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Tareas");
            intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(intent, "Compartir por"));
        }
    }
}
