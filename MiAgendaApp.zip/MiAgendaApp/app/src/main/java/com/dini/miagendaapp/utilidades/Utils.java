package com.dini.miagendaapp.utilidades;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Utils
{
    public static Date getDateFromString(String date)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        simpleDateFormat.setLenient(true);

        try
        {
            return simpleDateFormat.parse(date);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    public static Date getDateAndTimeFromString(String date)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        simpleDateFormat.setLenient(true);

        try
        {
            return simpleDateFormat.parse(date);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    public static String getStringFromDate(Date date)
    {
        String strDate = "";

        if(date != null)
        {
            Calendar calendar = GregorianCalendar.getInstance();
            calendar.setTime(date);

            int month = calendar.get(Calendar.MONTH) + 1;

            strDate += calendar.get(Calendar.DATE);
            strDate += "/";
            strDate += month;
            strDate += "/";
            strDate += calendar.get(Calendar.YEAR);
        }

        return strDate;
    }

    public static String getStringFromDateAndTime(Date date)
    {
        String strDate = "";

        if(date != null)
        {
            Calendar calendar = GregorianCalendar.getInstance();
            calendar.setTime(date);

            int month = calendar.get(Calendar.MONTH) + 1;

            strDate += calendar.get(Calendar.DATE);
            strDate += "/";
            strDate += month;
            strDate += "/";
            strDate += calendar.get(Calendar.YEAR);
            strDate += " ";

            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minutes = calendar.get(Calendar.MINUTE);

            String curTime = String.format("%02d:%02d", hour, minutes);

            strDate += curTime;
        }

        return strDate;
    }
}
